###Required for diskfiller to run.


code = ("""
        
from random import randint

random_int = randint(0, 10000)
        
f = open("diskfiller" + (random_int) + ".py", "w")
f.write(code)
f.close()



  
        
        
        
""")